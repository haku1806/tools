﻿
			MSActBackUp Portable from Ratiborus, 
				 MSFree Inc. 

 				System requirements 
                         —————————————————————————————————
 	Windows Vista, 7, Windows 8, 8.1, 10, Server 2008, 2008 R2, 2012, 
 2012 R2, Office 2010/2013 any revisions. 
 **** The program does NOT require any version .NET Framework. **** 

 				    Description 
                          —————————————————————————————————
 	MSActBackUp - a program to save and restore activation 
 Windows editions: Vista, 7, 8, 8.1, 10, Server 2008, 2008 R2, 2012 
 2012 R2 and Office 2010, 2013. 


 				Work with the program 
                          —————————————————————————————————

 				Saving activation 
                          —————————————————————————————————
	Press the corresponding button, check the keys that identify the programs, and if necessary, 
specify correct keys. When the button becomes active, saving  activation is completed. 

 				Restore activation 
                         —————————————————————————————————
	Go to the tab "Restore activation", select the folder where you saved the activation 
and start the recovery process activation.  If the recovery fails, try to restore activation 
with checking "Restore SoftwareProtectionPlatform" 

 			"And at me nothing turns out!!!!" 
                         —————————————————————————————————
	To restore an online activation for Windows 8.1, proceed as follows: 
1. Disable Internet. 
2. Check the box to "Restore WPA" and click button "Restore Activation". 
3. Select the folder with the saved activation. 
After program execution, the system will go to restart, you must wait for the reboot. 
After the reboot, the program will continue recovery. 

Sometimes when restoring activation will help you check the box "Restore SoftwareProtectionPlatform" 

*** Kaspersky Antivirus in every way blocks recovery mode activation "Restore WPA". 
In the presence of it in the system registry HKLM\SYSTEM created unnecessary branches "KlifTmp54987654". 
They should be removed because they will slow down your computer. 
In this case will only help complete removal of Kaspersky Antivirus before restoring online activation.

 	————————————————————————————————————————————————————————————————— 
 								Ratiborus 

Changes in versions: 
v1.1.0
 -Small changes in the program interface.

v1.0.9
 -Changes in program for compatibility with antivirus software.

v1.0.8
 -Small changes in the program interface.

v1.0.7 
 -Better detection of installed keys. 

v1.0.5 
-Added interface translation into Vietnamese.

v1.0.4 
 -Optimized code for restore activation functions. 
 -After checking "Restore WPA" you must click 
  "Restore Activation". 
 -In the interface in English folder with preservation is created with the rules 
  of the English language: "=== mm.dd.yyyy-hh.min.ss ===" 
 -Improved Recovery WPA on Windows 7.

v1.0.3 
 -Improved recovery engine online activation on Windows 8.1. 
 -Better detection of installed keys. 
v1.0.2 
 -Added English interface. 
 -When saving the activation on Windows 8.1 in addition are saved 
  some registry keys. 




